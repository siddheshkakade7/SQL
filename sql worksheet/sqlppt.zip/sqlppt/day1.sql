select * from employees;--sql query
select first_name,last_name,salary from employees;
select * from countries;

select * from countries where region_id=1;
--find all the records from employees where job_id is IT_PROG
select * from employees where job_id='IT_PROG';

describe employees;
desc locations;


select first_name,salary from employees;
select first_name,salary,salary+10000 from employees;
select first_name,salary,salary+(10000*2) as newsal from employees;
--alias :alternative name
select * from employees;
select first_name as name,salary as sal from employees;
select commission_pct comm from employees;
  
--null :unknown value
select comm from employees;

select first_name,salary,salary+10000 
as "salary with bonus" 
from employees;

--location id,street address,postal code,city  under name full address
select commission_pct  comm from employees;
select * from employees where commission_pct is null;

select first_name,commission_pct 
from employees 
where commission_pct is not null;

select job_id from employees; 

--distinct:used to eliminate duplicate data

select distinct job_id from employees;

select * from employees;

select distinct department_id from employees;
select distinct job_id,department_id from employees;
select distinct * from employees;

-----------day2-----------
select * from regions r;

--concatenation :attaching /concatenating/joining the column values 
describe employees;
select first_name||manager_id from employees;
select first_name||last_name||job_id from employees;
select first_name||' '||last_name||' '||job_id from employees;
select first_name||' '||last_name||' is '||job_id from employees;
--xyz has $1000 salary.
select first_name||' '||last_name||' has $'||salary||' salary.' 
as sal_stmt
from employees;
/* conactenate location id,street address,postal code,city
under name full address ,from locations table */
select count(*) from employees;
select count(*) from employees where job_id='SA_MAN';

select salary from employees;

select first_name,last_name,salary 
from employees 
where salary=17000 ;

select first_name,last_name,salary 
from employees 
where salary>17000 ;

select first_name,last_name,salary 
from employees 
where salary>10000 ;

select first_name,last_name,salary 
from employees 
where salary<=5000 ;

select first_name,salary from employees where salary<=3000;
select first_name,salary from employees where salary<>3000;
select first_name,salary from employees where salary!=3000;

--<> not equal to
-----day3---------
select first_name,last_name,salary 
from employees
where salary between 5000 and 10000; 
--select employees hired between 2001 to 2005
select hire_date from employees;
select first_name,last_name,hire_date
from employees 
where hire_date between '01-01-2001' and '31-12-2005';

select * from departments;
--print the names of departnaments having manager ids lying
--from 100 to 150
select department_name,manager_id 
from departments
where manager_id between 100 and 150;
--not between
select department_name,manager_id 
from departments
where manager_id not between 100 and 150;

--IN
select department_id,department_name,manager_id
from departments
where manager_id in(201,204,145,205);

select department_id,department_name,manager_id
from departments
where manager_id is null;

select * from regions;
select * from countries;

--display records of countries having region id 1,2,3
select * from countries where region_id in(1,2,3);
--display records of employees having salary 4000,9000,2900,2500 
select salary from employees;
select * from employees where salary in(4000,9000,2900,2500);

--not in
select * from employees where salary not in(4000,9000,2900,2500);

--SQL AND
select * from employees;
select first_name,last_name,job_id,department_id 
from employees 
where job_id=PU_CLERK' and department_id=30;

select first_name,last_name,job_id,department_id 
from employees 
where job_id in('PU_CLERK','SH_CLERK') and department_id in(30,50);

select first_name,salary,department_id 
from employees
where salary between 5000 and 10000 
and department_id between 30 and 50; 

 --SQL or
select job_id,salary from employees 
where job_id='PU_CLERK' or job_id='SH_CLERK';

--display records of departments having location_id 1500 or 1700
select department_id,department_name,manager_id,location_id 
from departments 
where location_id=1500 or location_id=1700;

------like operator
select first_name from employees where first_name like '%s%';
select first_name from employees;
--display name of employees starting with letter a
select first_name from employees where first_name like 'A%';
select first_name from employees where first_name like '%a%';

select first_name from employees where first_name like '_am%';

select first_name from employees where first_name like '_a%e_';
select first_name from employees where first_name like '__r%';


--day4
select * from employees;
--display employees hired in year 2005
select first_name,last_name,hire_date 
from employees
where hire_date between '31-12-2004' and '01-01-2006';

----display employees whose commission pct is unknown
--display employees whose commission pct is known
--display employee name,hiredate,jobid having manager id 114
select first_name,hire_date,job_id,manager_id
from employees
where manager_id=114;
--functions
select * from dual;

select * from jobs;
select lower(job_id) from jobs;
select job_id,upper(job_title) from jobs;

select lower('I AM HERE') from dual;

select initcap(email) from employees;
select initcap('I AM HERE') from dual;

select upper('i am here') from dual;
--substr :

select job_title,substr(job_title,5,4) from jobs;
select job_title,substr(job_title,5) from jobs;
select first_name,substr(first_name,2,3) from employees;

select substr('you can win',3) from dual;
select substr('you can win',3,5) from dual;

--length(column/expression)
select job_title,length(job_title) as len from jobs;
--display length of first_name from employees

--day5 28oct-
select * from dual;
select sysdate from dual;
--28-10-22
select * from regions;

select job_id from employees;

select first_name,last_name,concat(first_name,last_name) 
from employees;

select first_name||' '||last_name||' '||email as "full name" 
from employees;

--INSTR(string,substring[,position,occurrence])
select job_title from jobs;
select job_title,instr(job_title,'a') from jobs;
--find first occurence of 'a' in names of employees .
select first_name,instr(first_name,'a') from employees;
select instr('structured query language','u',5,2) from dual; --13
select instr('structured query language','u',1,2) from dual;--7
select instr('structured query language','u',1,3) from dual;--13

select job_title,instr(job_title,'at') from jobs;

--LTRIM
select job_id,ltrim(job_id,'IT') from employees;
select ltrim('aaabbbaaa','a') from dual;
select rtrim('aaabbbaaa','a') from dual;
--LPAD(�string�, length, character to pad);
select email from employees;
select email,lpad(email,15,'$') from employees;
select email,rpad(email,20,'*') from employees;

--REPLACE(string, string_to_replace, replacement_string);
select replace('structured query language','query','ddl/dml')
from dual;

select job_id from employees;
select job_id,replace(job_id,'account','acc') from employees;--not work
select job_id,replace(job_id,'ACCOUNT','acc') from employees;

select reverse('structured query language') from dual;

--day6 _31oct
select unique job_id from employees;
select distinct job_id from employees;



select job_id as profile,commission_pct commission,first_name name
from employees;
--round(number,deimal place) :
select round(345.356,2) from dual;--345.36
select round(56.22,2) from dual; --56.22
select round(56.22,0) from dual; --56
select round(56.99,0) from dual; --56
select round(456.678,-1) from dual; --460
select round(456.678,-2) from dual; --500

--trunc(number,decimal place)
select trunc(345.784,2) from dual;--345.78
select trunc(345.784999,3) from dual;--345.784
select trunc(345.784,0) from dual;--345
select trunc(345.784,-1) from dual;--340
select trunc(345.784,-2) from dual;--300
select trunc(389.784,-2) from dual;--300

--MOD(m,n)
select mod(1200,300) from dual; --0
select mod(1200,500) from dual; --200

select first_name,salary from employees;
select first_name,salary,mod(salary,300) as rem from employees;
select first_name,job_id,salary,mod(salary,300) as rem from employees
where job_id='IT_PROG';

--ceil(number)
select ceil(453.45) from dual; --454
select floor(453.45)from dual;--453
select ceil(453.9999) from dual;--454
select floor(453.9999) from dual;--453

--power(m,n)
select power(2,3) from dual; --8
select power(16,5) from dual;
--sqrt(number)
select sqrt(256) from dual;
select sqrt(4) from dual;
select sqrt(4465.687) from dual; 
select round(sqrt(4465.687),2) from dual;

--day7 1Nov
select sysdate from dual;
select current_date from dual;
select sessiontimezone from dual;
select systimestamp from dual;
select current_timestamp from dual;

select hire_date from employees;

--ADD_MONTHS(date,n):Adds months to a date

select hire_date,add_months(hire_date,3) prob_period 
from employees;
select first_name,job_id,hire_date,add_months(hire_date,3) prob_period 
from employees 
where job_id='IT_PROG';
select first_name,job_id,hire_date,add_months(hire_date,3) prob_period 
from employees 
where job_id='IT_PROG';

select * from job_history;

--MONTHS_BETWEEN(DATE1,DATE2)
select start_date,end_date,months_between(end_date,start_date),
trunc(months_between(end_date,start_date),2) mon_diff
from job_history;

select trunc(months_between(end_date,start_date),2) 
from job_history;
select months_between(sysdate,'21-10-22') from dual;
select months_between(sysdate,'01-11-20') from dual;

select start_date,end_date,ceil (round (months_between(end_date,start_date),2))as figure 
from job_history;

--ROUND(date,format)
select sysdate,round(sysdate,'year') from dual;

select sysdate,round(sysdate,'month') from dual;

select first_name,job_id,hire_date,round(hire_date,'month') 
from employees
where job_id='PU_CLERK';

select * from employees;
select sysdate,round(sysdate,'day') from dual;
select hire_date,round(hire_date,'day') from employees; 

select sysdate,to_char(sysdate,'dy'),
round(sysdate,'day'),to_char(round(sysdate,'day'),'dy') from dual;

select hire_date,to_char(hire_date,'dy'),
round(hire_date,'day'),to_char(round(hire_date,'day'),'dy')
from employees; 

--EXTRACT(date_component from date)
select extract(month from sysdate) from dual;
select extract(year from sysdate) from dual;
select extract(day from sysdate) from dual;

--display year of hiring of all the employees from emlpoyees table
--NEXT_DAY(date,day of week)
select next_day(next_day(sysdate,'tuesday'),'tuesday') from dual;
select next_day(sysdate,'sunday') from dual;

--LAST_DAY(date)
select last_day(sysdate) from dual;

select to_char(sysdate,'dy') from dual;

--day8_2Nov
--to retrieve year from date
select sysdate,to_char(sysdate,'yyyy') from dual;
select sysdate,to_char(sysdate,'yyy') from dual;
select sysdate,to_char(sysdate,'yy') from dual;

--display 4 digits of year from hiredate in employees table
--to retrieve months from date
select hire_date,to_char(hire_date,'mm') from employees;
select hire_date,to_char(hire_date,'mon') from employees;
select hire_date,to_char(hire_date,'month') from employees;

--to retrive day from date
--to retrieve months from date
select hire_date,to_char(hire_date,'day') from employees;
select hire_date,to_char(hire_date,'dd') from employees;
select hire_date,to_char(hire_date,'ddd') from employees;
select hire_date,to_char(hire_date,'d') from employees;
select hire_date,to_char(hire_date,'dy') from employees;

select hire_date,to_char(hire_date,'dd/mon/yyyy') from employees;
select hire_date,to_char(hire_date,'dd month,yy') from employees;
select hire_date,to_char(hire_date,'dd mon yyyy') from employees;

--order by clause
select first_name,last_name,salary 
from employees
order by salary; 

select salary from employees;

select first_name,last_name,salary 
from employees
order by first_name; 

select first_name,last_name,salary 
from employees
order by first_name desc; 

select first_name,last_name,salary 
from employees
order by first_name desc,last_name; 

select first_name,last_name,salary 
from employees
order by first_name desc,last_name desc; 

--    TRIM([[LEADING|TRAILING|BOTH] trim_character from] string);
select trim(leading 0 from '000aaa000') from dual;
select trim(trailing 0 from '000aaa000') from dual;
select trim(both 0 from '000aaa000') from dual;
select trim(leading 'a' from 'aaabbaa') from dual;
select job_id from employees; 
--    TRIM([[LEADING|TRAILING|BOTH] trim_character from] string);
select trim(leading 0 from '000aaa000') from dual;
select trim(trailing 0 from '000aaa000') from dual;
select trim(both 0 from '000aaa000') from dual;

select job_id,trim(leading 'SA' from job_id) from employees;
--two characters not allowed
select job_id,trim(leading 'S' from job_id) from employees;

select job_id,trim(leading 'S' from job_id),
trim(leading 'A' from (trim(leading 'S' from job_id))) from employees;

--day9---4thNov,2022
select salary oldsal,salary+5000 as newsal from employees; 
select commission_pct,commission_pct+0.2 revisedComm 
from employees;

--NVL(Expression 1, Expression 2)
select commission_pct,nvl(commission_pct,0) from employees;

select commission_pct,nvl(commission_pct,'0')+0.2 revisedComm 
from employees;

select first_name,salary,commission_pct,
salary+nvl(commission_pct,'0')*10000 newsal
from employees;

--NVL2(exp1,exp2,exp3)
select commission_pct,nvl2(commission_pct,'getting comm','no comm')
from employees;

--nullif(exp1,exp2)
select first_name,length(first_name) exp1,job_id,length(job_id) exp2,
nullif(length(first_name),length(job_id))
from employees;

--COALESCE( Expression 1, Expression 2,�..Expression N)
select commission_pct,salary,
coalesce(commission_pct,salary,10000) 
from employees;

insert into employees(first_name,salary) values ('amit',null);

select * from student1;

insert into student(

select commission_pct,salary,
coalesce(commission_pct,10000) 
from employees;

select * from countries; 
select * from locations; 
select postal_code,state_province,
coalesce(postal_code,state_province,'reached') 
from locations;

--DECODE(column/expression,search1,result1,search2,result 2,default)
select first_name,job_id,salary,
decode(job_id,'IT_PROG',salary*1.3,'SH_CLERK',salary*1.1,salary)
as revisedSal
from employees;

select first_name,job_id,salary,
decode(job_id,'IT_PROG',salary*1.3,'SH_CLERK',salary*1.1,55555)
as revisedSal
from employees;

select * from employees;

-- day 10: 7th Nov
/*1)	department_id        grade
        90                            A
        80                            B
        70                           C
        60                           D
        Default             �not found� */
        
select department_id,decode(department_id,'90','A','80','B',70,
'C',60,'D','not found') as grades from departments;

--- aggregate functions--
select sum(salary),avg(salary) from employees;
select max(salary),min(salary) from employees;

select min(first_name),min(hire_date),min(commission_pct) 
from employees;

--select avg(10,20,30,40,50) from dual;--wont work

--count
select count(*) from employees;--107
select count(*),count(commission_pct) from employees;--35
select count(*),count(commission_pct),count(distinct commission_pct)
from employees;

select commission_pct from employees 
where commission_pct is not null;--to cross check ans 35

--display count of different job_id in employee table--19
--display count of different manager_id in employee table--18

--LISTAGG(column name[,delimeter] within group order by [sort-expression])

select commission_pct from employees;

select listagg(commission_pct,',') within group 
(order by commission_pct desc ) from employees;

--apply listagg function for first_name in employees table.
--use delimiter as $
select listagg(commission_pct,'$') within group 
(order by commission_pct desc) from employees;

select listagg(commission_pct,'$') within group 
(order by commission_pct) from employees;


select distinct job_id from employees;--19

select job_id from employees;--19

--group by clause

select job_id from employees group by job_id;
select job_id from employees group by job_id;

select job_id,sum(salary) from employees group by job_id;

select * from employees;

select job_id from employees group by job_id;
select manager_id,count(*) from employees group by manager_id;

--day11 8 th Nov
--1)display records of departments having 1500 or 1700
--2)Display the difference between highest and lowest salary 
--  from employees.
select max(Salary)-min(salary) from employees;

--display number of employees(i.e.count) working as sales representative.
select count(*) from employees where job_id='SA_REP';---30
--Find out count of employee according to dept_id
select distinct department_id  from employees; 
select department_id from employees group by department_id;

select department_id,count(employee_id) from employees
group by department_id;

/*display department_id,count of employees working in each 
department,names of all employees working in same department */

select department_id,count(employee_id),
listagg(first_name,',') within group (order by first_name)
from employees
group by department_id;

---having clause : works with groups only
select department_id,count(employee_id) from employees
group by department_id having count(employee_id)>25;

select department_id,count(employee_id) from employees
group by department_id having count(employee_id)<5;

select department_id,count(employee_id) from employees
group by department_id having count(employee_id)<5 
order by department_id asc;

--Display number of departments(count) having location id 1700 
--(refer department table)
select * from departments;
select location_id,count(*) from departments where location_id=1700;

select location_id,count(*) from departments 
group by location_id having location_id=1700; 

select location_id,count(*) from departments 
group by location_id having count(*)<5;

select location_id,count(*) from departments 
group by location_id where manager_id=200; --it will not work

select location_id,count(*) from departments where manager_id=200
group by location_id;

select job_id,max(salary),min(salary),avg(salary)
from employees group by job_id;

-----day12  9th Nov
--DDL:data definition language
--creation of table:
[16:05] 3RI Trainings
create table Book(bookid int,bookname varchar(20),author varchar(20));
desc book;

--adding column
alter table book add price int;
desc book;
--deleting the column
alter table book drop column bookid ;
desc book;
--
select * from student;
alter table student add xyz varchar(20);
select * from student;

---to create copy of employees table
create table empcpy as select * from employees;
select * from empcpy;
drop table empcpy; --removes table from database
select * from empcpy;
-----------------modify command to change type of attribute
desc book;
alter table book add id date;
desc book;
alter table book modify(id int);
---renaming column
alter table book rename column price to cost;
desc book;
--renaming table
alter table book rename to ref_book;
desc book;
desc ref_book;

--detailed information about table
information employees;
information ref_book;
comment on table ref_book is 'detailed book information'; 
information ref_book;

--comment on column
comment on column ref_book.id is 
'id gives unique identification of books';

---truncate :removes all rows from table
create table e2 
as select first_name,job_id,salary 
from employees
where job_id in('IT_PROG','SA_MAN','PU_CLERK');

select * from e2;
truncate table e2;
select * from e2;
-------------------------------------------------------------
--10 th nov
--DML :data manipulation language
--insert : inserting the vlues in table
desc ref_book;
insert into ref_book
values('wings of fire','Abdul kalam',1200,100);
select * from ref_book;

insert into ref_book(id,bookname) values(200,'chhava');
insert into ref_book(author) values('shivaji sawant');--insert new row
--updating earlier existing row
update ref_book set author='shivaji sawant' where id=200;
select * from ref_book;
update ref_book set cost=1200 where id=200;
select * from ref_book;

----deleting rows from table
delete from ref_book;
select * from ref_book; --deletes all the rows

rollback;
select * from ref_book;
---delete specific rows
delete from ref_book where id=200;
select * from ref_book;

----rownum: temporary,rowid:permanent
select first_name,rownum,rowid from employees;
select first_name,rownum,rowid from employees 
where job_id='IT_PROG';

select * from locations;
select location_id,rownum,rowid from locations;

select bookname,rownum,rowid from ref_book;
desc ref_book;
select id,rownum,rowid from ref_book;
select * from ref_book;

delete from ref_book where rowid='AAAFC3AAEAAAAGmAAA';
select * from ref_book;

-----to limit the number of rows to be fetched from d/b
select * from employees where rownum<50;
select * from employees where rownum<6;
select * from employees where rownum<=5;

select first_name,job_id,rownum
from employees 
where job_id='IT_PROG' or rownum<=3;

--TCL :transaction control language
--rollback,commit,savepoint
select * from ref_book;
rollback;
select * from ref_book;
insert into ref_book values('aaa','bbb',200,111);
insert into ref_book values('mmm','nnn',500,222);
insert into ref_book values('yyy','zzz',100,67);
select * from ref_book;
commit;--it saves data permanently
rollback;--will not work after commit
select * from ref_book;
--------------------------------
--------------------------------
--11 nov
drop table x;
create table x(id int,name varchar(20));
insert into x values(01,'xyz');
insert into x(name,id) values ('abc','02');
select * from x;
delete from x where id=01;
select * from x;
savepoint a;
insert into x values(03,'aaa');
insert into x values(04,'bbb');
insert into x values(05,'ccc');
savepoint b;
insert into x values(04,'ddd');
insert into x values(05,'eee');
savepoint c;
insert into x values(07,'fff');
insert into x values(08,'ggg');

select * from x;
rollback to c;
select * from x;

rollback to b;
select * from x;
---------------------
drop table x;
create table x(id int,name varchar(20));
insert into x values(01,'xyz');
insert into x(name,id) values ('abc','02');
select * from x;
savepoint a;
insert into x values(03,'aaa');
insert into x values(04,'bbb');
insert into x values(05,'ccc');
savepoint b;
insert into x values(07,'fff');
insert into x values(08,'ggg');
select * from x;
commit;
rollback to b;
update x set id=09 where id=08;
select * from x;
rollback;
select * from x;
--constraints :
--not null
drop table a;
create table a
(id int constraint nn_id2 not null);

insert into a values(10);
insert into a values(null);
insert into a values(20);
insert into a values(0);
select * from a;
----14 november
--unique : avoids duplicate data
create table b
(
   id int not null,
   email varchar2(20) constraint email_cn unique--column level constraint
);
insert into b values(101,'aaa');
insert into b values(101,'aaa');--gives error
---
create table aa(name varchar2(15) unique); 
create table emp
(
  id int,
  name varchar(20),
  email varchar2(20),
  constraint uni_cn_id unique(id),--table level constraint
  constraint apurva_email unique(email)--table level constraint
)
drop table emp;

insert into emp values(111,'ddd','abc@.com');
insert into emp values(111,'eee','xyz@.com');
insert into emp values(222,'fff','abc@.com');
--------------
--primary key constraint :combination of unique and not null constraints
drop table a;

create table a
(
  id int constraint pk_id primary key,
  name varchar2(20)
);

insert into a values(111,'aaa');
insert into a values(111,'aaa');
insert into a values(null,'aaa');
--check constraint: 
create table stud123
(
    id int,
    name varchar2(15),
    marks number(5,2) constraint check_con_marks check(marks>35)
);
insert into stud123 values(111,'jay',67.89);
insert into stud123 values(221,'viru',22.45);

-------------------------
drop table a;
drop table aa;
drop table b;
drop table emp;
drop table y;
select * from y;
select * from z;
drop table stud;
drop table stud123;
drop table student1;
drop table z;
-----15 nov
create table student
(
  id int,
  name varchar2(20),
  email varchar2(20) constraint  email_cn check(email like '%.com')
);

insert into student values(111,'aaa','xyz.com');
insert into student values(222,'bbb','fghgjh'); --should give error

------------
drop table student; 
select * from employees; --employees table is child table
select * from departments; --department table is parent table
--primary key helps us to identify records uniquely
--one table contains only one primary key

----------
drop table course;
create table course  --parent table
(
  cid int constraint pk_cid primary key,
  name varchar2(20)
);
insert into course values(101,'java');
insert into course values(1111,'AWS');
insert into course values(1234,'selenium');
select * from course;


drop table student;
create table student --child table
(
  sid int constraint stud_id_cn primary key,
  sname varchar2(20),
  course_id int constraint fk_crs_id references course(cid)
);
insert into student values(1,'amit',101);
insert into student values(23,'tejas',1111);
insert into student values(36,'divya',1111);
insert into student values(89,'kavya',1234);
insert into student values(90,'adi',101);
insert into student values(2,'sumit',55565);

select * from student; 

-----------
drop table course;
drop table student;

---adding constraints after creating table
create  table course
(
  cid int,
  cname varchar2(20)
);
create table student 
(
 sid int,
 sname varchar2(20),
 course_id int
);

alter table course add constraint pk_cn_cid primary key(cid);

alter table student add constraint fk_cn_crs12 
foreign key(course_id) references course(cid);

select * from employees;

---------------------------------
--16 nov
create table emp(id int,name varchar2(20),sal int);
alter table emp add constraint uni_id_cn123 unique(id);
alter table emp add constraint check_sal check(sal>'0');

alter table emp modify name constraint nn_name not null;
---------------
--dropping the constraints 

alter table emp drop constraint uni_id_cn123;
alter table emp drop constraint check_sal;
alter table emp drop constraint nn_name;

-------------
select * from course;
select * from student;


create table x(xid int primary key,name varchar2(20));
insert into x values(111,'aaa');
insert into x values(222,'bbb');
insert into x values(333,'ccc');
select * from x;

create table y(yid int,xid int references x(xid));
desc y;
insert into y values(1,111);
insert into y values(12,333);
select *  from y;

alter table x drop constraint SYS_C007082;
--should not get droppes as it is referred in child table y. 
alter table x drop constraint SYS_C007082 cascade;
--cascade will drop primary key constraint along with all the references
select * from x;
select * from y;

insert into y values(4,678);

--------------
create table b
(
  id int,
  name varchar2(20),
  email varchar2(20),
  constraint cn_comb3 unique(id,name,email)
);
insert into b values(1,'aa','aa.com');
insert into b values(2,'aa','aa.com');
insert into b values(1,'aa','aa.com');
insert into b values(1,'bb','aa.com');

-------17 nov
--set operators :
drop table a;
drop table b;
drop table x;
drop table y;
drop table emp;

create table x(id int,name varchar2(20));
insert into x values(10,'aaa');
insert into x values(20,'bbb');
insert into x values(30,'ccc');
insert into x values(40,'ddd');
insert into x values(89,'iii');
insert into x values(7,'ppp');

create table y(yid int);
insert into y values(67);
insert into y values(67);
insert into y values(67);
insert into y values(89);
insert into y values(7);
insert into y values(20);

select * from x;
select * from y;

select id from x
union
select yid from y; 

select id from x
union all
select yid from y;

select id from x
intersect
select yid from y;

select id from x
minus
select yid from y;
----------
drop table ref_book;
create table ref_book(subject varchar2(20),author varchar2(20)); 
insert into ref_book values('c','yashwant kanetkar');
insert into ref_book values('c','balgurusamy');
insert into ref_book values('java','herbert schildt');
insert into ref_book values('networking','fourozoun');
insert into ref_book values('OS','galvin');
insert into ref_book values('RDBMS','henry korth');
select * from ref_book;

create table books(technology varchar2(20),author varchar2(20));
insert into books values('RDBMS','henry korth');
insert into books values('OS','galvin');
insert into books values('SE','robert ceciel martin');

select * from ref_book;
select * from books;

select subject from ref_book
union all
select technology from books;

select subject from ref_book
union 
select technology from books;

select subject from ref_book
intersect
select technology from books;

-----


select subject from ref_book
minus
select technology from books;

create table stud(id int,name varchar2(20),dob date);
select sysdate from dual;
insert into stud values(111,'anita','12-09-1989');
select * from stud;

----21 nov
---cross join/cartesian product
select * from jobs;--19
select * from locations;-- rows

select * from jobs cross join locations; --437 rows

create table ice_cream(flavour varchar2(20));
insert into ice_cream values('chocolate');
insert into ice_cream values('guava');
insert into ice_cream values('jamun');

create table scoop(size1 varchar2(20));
insert into scoop values('small');
insert into scoop values('medium');
insert into scoop values('large');

select * from ice_cream cross join scoop;

---natural join
select * from employees;
select * from departments;
desc employees;
desc departments;
select * from locations;
select * from employees natural join departments natural join locations;

select * from student_details;
/*111	anish	1
231	nandita	6
789	amna	1 */

select * from course_details;
/*
1	fullstacck java	45000
6	fullstacck python	37000
11	testing	32000
23	AWS	49000
*/
select * from student_details natural join course_details;
/*
1	111	anish	fullstacck java	45000
6	231	nandita	fullstacck python	37000
1	789	amna	fullstacck java	45000
*/
desc course_details;

-- inner join :we can provide column name to join the tables
select * from employees;
select * from departments;

select * from employees 
inner join 
departments using(manager_id); --44 rows

select * from employees 
inner join 
departments using(department_id);--106 rows

--equi join
select * from jobs;
select e.first_name,e.job_id from employees e;

select e.first_name,e.job_id,j.job_title 
from employees e,jobs j
where e.job_id=j.job_id;


----22 nov

--self join
select employee_id,first_name,manager_id from employees;
--employees e
--employees m
select e.employee_id,e.first_name,e.manager_id,m.first_name 
from employees e,employees m
where e.manager_id=m.employee_id;

---outer join

select * from employee;
drop table employee;
drop table empDetails;

create table employee(emp_id int,name varchar2(20));
insert into employee values(11,'anil');
insert into employee values(12,'sunil');
insert into employee values(13,'pranil');
insert into employee values(25,'anay');

create table empDetails(emp_id int,age int,city varchar2(20));
insert into empDetails values(11,34,'pune');
insert into empDetails values(12,28,'mumbai');
insert into empDetails values(13,45,'banglore');
insert into empDetails values(14,42,'goa');
insert into empDetails values(15,28,'thane');
insert into empDetails values(16,30,'baroda');


select * from employee; 
select * from empDetails;

select e.emp_id,e.name,d.emp_id,d.age,d.city
from employee e 
left join empDetails d
on(e.emp_id=d.emp_id);

--left outer join
select e.emp_id,e.name,d.emp_id,d.age,d.city
from employee e 
left join empDetails d
on(e.emp_id=d.emp_id)
where d.emp_id is null;

--right join
select e.emp_id,e.name,d.emp_id,d.age,d.city
from employee e 
right join empDetails d
on(e.emp_id=d.emp_id);

--right outer join
select e.emp_id,e.name,d.emp_id,d.age,d.city
from employee e 
right join empDetails d
on(e.emp_id=d.emp_id)
where e.emp_id is null;

--full join
select e.emp_id,e.name,d.emp_id,d.age,d.city
from employee e 
full join empDetails d
on(e.emp_id=d.emp_id);

--23 rd nov
--subqueries :query within query
             --nested query
             -- 1)single row subquery
             -- 2)multiple row subquery
select * from employees;

select first_name,last_name,job_id,salary 
from employees where employee_id=110;

select first_name,last_name,job_id,salary
from employees where salary>8200;

select salary from employees where employee_id='110';

select first_name,last_name,job_id,salary
from employees where salary>
(select salary from employees where employee_id='110');
    --here employee_id is unique 
             
select salary from employees where first_name like 'William';    

--find record of employee having highest salary
select max(salary) from employees;

select first_name,last_name,salary from employees
where salary=(select max(salary) from employees);
             
--find record of employee having lowest salary
--find record of employee hired recently
select hire_date from employees; 
select max(hire_date) from employees;

select * from employees 
where hire_date=(select max(hire_date) from employees);

--find record of employee having second highest salary

 select max(salary) from employees where salary<
(select max(salary) from employees);

---multiple row subquery: IN,ANY,ALL
select salary from employees 
where job_id='SA_MAN';

select first_name,job_id,salary from employees
where salary IN(select salary from employees 
where job_id='SA_MAN');

select first_name,job_id,salary from employees
where salary IN(14000,13500,12000,11000,10500);

select first_name,job_id,salary from employees
where salary > ANY(select salary from employees 
where job_id='SA_MAN');

select first_name,job_id,salary from employees
where salary < ANY(select salary from employees 
where job_id='SA_MAN');

select first_name,job_id,salary from employees
where salary > ALL(select salary from employees 
where job_id='SA_MAN');

select * from employees;

---24 nov
--DCL: 
-- grant
-- revoke
